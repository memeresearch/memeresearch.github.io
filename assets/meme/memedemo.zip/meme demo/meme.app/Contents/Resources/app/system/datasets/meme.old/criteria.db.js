module.exports = [
  {
    id: 1,
    label: 'Clarity',
    description: 'How clear is the explanation?',
    classroomId: 1
  },
  {
    id: 2,
    label: 'Visuals',
    description: 'Does the layout make sense?',
    classroomId: 1
  }
];
