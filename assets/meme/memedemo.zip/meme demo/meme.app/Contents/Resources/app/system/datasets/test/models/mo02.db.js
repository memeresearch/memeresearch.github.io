module.exports = {
  // pmcdata id
  id: 2,
  // components is a 'component' or a 'property' (if it has a parent)
  entities: [
    { id: 10, type:'prop', name: 'tank' },
    { id: 11, type:'prop', name: 'fish' }
  ],
  visuals: [
  ]
};
