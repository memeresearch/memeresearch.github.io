module.exports = [
  { id: 1, name: 'Period 1', teacherId: 1 }
];
