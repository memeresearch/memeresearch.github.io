const mo1 = require(`./models/mo01.db`);

const Data = [mo1];

module.exports = Data;
