module.exports = [
  {
    classroomId: 1,
    definitions: [
      { label: 'Rocks!!', rating: 3 },
      { label: 'Medium support', rating: 2 },
      { label: 'Weak support', rating: 1 },
      { label: 'Not rated / Irrelevant', rating: 0 },
      { label: 'Disagrees a little', rating: -1 },
      { label: 'Kinda disagrees!', rating: -2 },
      { label: 'Really disagrees!', rating: -3 }
    ]
  }
];
