module.exports = [
  { id: 1, name: 'Ms Brown' },
  { id: 2, name: 'Mr Smith' },
  { id: 3, name: 'Ms Gordon' }
];
