/* placeholder for event definition */

/// MODULE DECLARATION ////////////////////////////////////////////////////////
/// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
const KnownEvents = {};

/* eslint-disable import/prefer-default-export */
export { KnownEvents };
