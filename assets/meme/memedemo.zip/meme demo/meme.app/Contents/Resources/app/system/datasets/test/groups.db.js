module.exports = [
  { id: 1, name: 'Blue', students: ['Bob', 'Bessie', 'Bill'], classroomId: 1 },
  { id: 2, name: 'Green', students: ['Ginger', 'Gail', 'Greg'], classroomId: 1 },
  { id: 3, name: 'Red', students: ['Rob', 'Reese', 'Randy'], classroomId: 1 },
  { id: 4, name: 'Purple', students: ['Peter', 'Paul', 'Penelope'], classroomId: 1 },
  { id: 5, name: 'Mackerel', students: ['Mary', 'Mavis', 'Maddy'], classroomId: 1 }
];
