const mo1 = require(`./models/mo01.db`);
const mo2 = require(`./models/mo02.db`);

const Data = [mo1, mo2];

module.exports = Data;
