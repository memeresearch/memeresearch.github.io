module.exports = [
  { id: 1, classroomId: 1, resources: [1, 2, 7, 11] }, // PMCData resources
  { id: 2, classroomId: 2, resources: [2, 3] },
  { id: 3, classroomId: 3, resources: [4, 5] },
  { id: 4, classroomId: 3, resources: [6, 7] }
];
