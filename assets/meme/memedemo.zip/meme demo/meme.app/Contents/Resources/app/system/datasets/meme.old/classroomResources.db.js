module.exports = [
  { id: 1, classroomId: 1, resources: [1, 2] }
];
