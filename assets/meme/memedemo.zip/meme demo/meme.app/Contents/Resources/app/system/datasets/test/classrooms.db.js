module.exports = [
  { id: 1, name: 'Period 1', teacherId: 1 },
  { id: 2, name: 'Period 3', teacherId: 1 },
  { id: 3, name: 'Period 2', teacherId: 2 },
  { id: 4, name: 'Period 3', teacherId: 2 }
];
