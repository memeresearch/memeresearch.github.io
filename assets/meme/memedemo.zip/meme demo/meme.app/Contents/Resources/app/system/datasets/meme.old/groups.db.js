module.exports = [
  { id: 1, name: 'Blue', students: ['Bob', 'Bessie', 'Bill'], classroomId: 1 }
];
