const models = [
  { id: 1, title: 'Fish Sim', groupId: 1, dateCreated: '', dateModified: '', pmcDataId: 1 },
  { id: 2, title: 'Tank Sim', groupId: 5, dateCreated: '', dateModified: '', pmcDataId: 2 },
  { id: 3, title: 'Ammonia', groupId: 1, dateCreated: '', dateModified: '', pmcDataId: 2 },
  { id: 4, title: 'Fish Sim', groupId: 2, dateCreated: '', dateModified: '', pmcDataId: 2 },
  { id: 5, title: 'Tank Sim', groupId: 2, dateCreated: '', dateModified: '', pmcDataId: 2 },
  { id: 6, title: 'Fish Sim', groupId: 4, dateCreated: '', dateModified: '', pmcDataId: 2 },
  { id: 7, title: 'No Sim', groupId: 4, dateCreated: '', dateModified: '', pmcDataId: 2 },
  { id: 8, title: 'Fish Sim', groupId: 4, dateCreated: '', dateModified: '', pmcDataId: 2 },
  { id: 9, title: 'Tank Sim', groupId: 4, dateCreated: '', dateModified: '', pmcDataId: 2 },
  { id: 10, title: 'Fish Sim', groupId: 4, dateCreated: '', dateModified: '', pmcDataId: 2 },
  { id: 11, title: 'No Sim', groupId: 5, dateCreated: '', dateModified: '', pmcDataId: 2 }
];

module.exports = models;
