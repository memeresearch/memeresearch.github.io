module.exports = [
  {
    id: 1,
    classroomId: 1,
    sentences: 'I noticed...\nI think...'
  }
];
