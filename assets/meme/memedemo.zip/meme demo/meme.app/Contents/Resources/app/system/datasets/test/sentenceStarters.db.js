module.exports = [
  {
    id: 1,
    classroomId: 1,
    sentences: 'I noticed...\nI think...'
  },
  {
    id: 2,
    classroomId: 2,
    sentences: 'We noticed...'
  },
  {
    id: 3,
    classroomId: 3,
    sentences: 'We believe...'
  }
];
