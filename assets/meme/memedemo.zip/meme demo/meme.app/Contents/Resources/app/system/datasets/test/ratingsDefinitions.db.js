module.exports = [
  {
    classroomId: 1,
    definitions: [
      { label: 'Rocks!!', rating: 3 },
      { label: 'Medium support', rating: 2 },
      { label: 'Weak support', rating: 1 },
      { label: 'Not rated / Irrelevant', rating: 0 },
      { label: 'Disagrees a little', rating: -1 },
      { label: 'Kinda disagrees!', rating: -2 },
      { label: 'Really disagrees!', rating: -3 }
    ]
  },
  {
    classroomId: 2,
    definitions: [
      { label: 'Will this!', rating: -2 },
      { label: 'break', rating: -1 },
      { label: 'with not', rating: 0 },
      { label: 'enough', rating: 1 },
      { label: 'elements', rating: 2 },
      { label: 'here?', rating: 3 }
    ]
  }
];
